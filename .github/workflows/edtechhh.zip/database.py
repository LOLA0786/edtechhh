def init_db(): pass
