def start_auto(): return 'started'
