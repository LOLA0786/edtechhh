def generate_summary_for_lesson(id,lang='en'): return {'ok':True,'summary':'demo'}
