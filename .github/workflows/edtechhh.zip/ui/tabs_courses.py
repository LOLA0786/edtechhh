def register_courses_tab(b): pass
