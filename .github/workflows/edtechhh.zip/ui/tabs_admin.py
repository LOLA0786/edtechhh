def register_admin_tab(b): pass
