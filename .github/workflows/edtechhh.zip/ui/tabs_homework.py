def register_homework_tab(b): pass
