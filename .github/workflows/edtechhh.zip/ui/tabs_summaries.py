def register_summaries_tab(b): pass
