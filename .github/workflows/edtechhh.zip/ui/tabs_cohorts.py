def register_cohorts_tab(b): pass
