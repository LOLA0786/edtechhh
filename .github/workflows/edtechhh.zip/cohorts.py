def create_cohort(a,b,c=''): return {'ok':True}
