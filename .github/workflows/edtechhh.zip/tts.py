def generate_tts_for_lesson(id,lang='en'): return {'ok':True,'path':None}
