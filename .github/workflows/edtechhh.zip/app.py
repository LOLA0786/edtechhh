print('EdTech App Placeholder Loaded')
