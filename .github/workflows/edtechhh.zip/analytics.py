def get_system_stats(): return {'users':1}
