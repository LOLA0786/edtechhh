def submit_homework(a,b,c): return {'ok':True}
